﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MvcShoe.Models;

namespace MvcShoe.Data
{
    public class MvcShoeContext : DbContext
    {
        public MvcShoeContext (DbContextOptions<MvcShoeContext> options)
            : base(options)
        {
        }

        public DbSet<MvcShoe.Models.Shoe> Shoe { get; set; } = default!;
    }
}
